#include <stdio.h>
#include <stdlib.h>

unsigned reverseBits(unsigned val);
void display(unsigned val);

int main()
{
    unsigned a;
    printf("Enter an integer:");
    scanf("%u",&a);
    printf("Original integer in bits:\n");
    display(a);

    a=reverseBits(a);
    printf("Integer after reversing order of bits:\n");
    display(a);

    return 0;
}

unsigned reverseBits(unsigned val)
{
    unsigned mask=1;
    unsigned temp=0;
    int i;
    for(i=0; i<=15; i++)
    {
        temp<<=1;
        temp|=(val & mask);
        val>>=1;
    }
    return temp;
}
void display(unsigned val)
{
    unsigned c;
    unsigned displayMask=1<<15;
    printf("%u\t",val);
    for(c=1; c<=16; c++)
    {
        val&displayMask?putchar('1'):putchar('0');
        val<<=1;
        if(c%8==0)
        {
            putchar(' ');
        }
    }
    putchar('\n');
}
