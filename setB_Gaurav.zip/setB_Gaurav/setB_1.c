#include <stdio.h>
#include <string.h>
#include <math.h>

void removeCharacter(char str[], int i)
{
    for(;str[i]!='\0';)
    {
        str[i]=str[i+2];
        str[i+1]=str[i+3];
        i+=2;

    }
}

int main()
{
    int i=0,len=0;
    int s;

    scanf("%d",&s);

    char str[s];

    scanf("%s",str);

    if(strlen(str)==s)
    {
        for(;str[len]!='\0';len++);
        for(;i<len;)
        {
            if((str[i] == str[i+1] ) && (i >= 0) && str[i]!='\0')
            {
                removeCharacter(str,i);
                i--;
            }
            else
            {
                i++;
            }
        }
        if(str[0]=='\0')
           printf("Empty String");
        else
           printf("%s\n",str);
    }

    return 0;
}
